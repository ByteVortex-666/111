﻿dsh-whale-splash · DeepSeek 开屏动画（朋友分享版）

【这是什么】
打开 DSH 时先播一段 HARNESS OS 开机过场：
鲸鱼标志 → 需要访问许可 → 身份资料确认 → 接收访问需求
→ 开始读取权限 → 读取完毕·核验通过 → WELCOME TO HARNESS OS。
带 HUD、四角框、打字机英文、读取条、核验圆环；开屏时会把右上角
白色窗口按钮隐藏/变黑，并进入全屏，播完自动恢复。

【怎么装】
1. 先把整个压缩包解压到一个固定文件夹（不要直接在压缩包里运行）。
2. 双击 INSTALL.bat，等它显示“安装完成”。
3. 完全退出 DSH（关窗口、托盘也退干净），再重新打开。
4. 想调设置：DSH 里打开 设置 → 开屏动画。

【安装失败怎么办】
- 提示找不到 dsh：请确认用的是官方 DeepSeek Harness，并且装在了默认位置；
  也可以打开 PowerShell 手动执行：
    dsh plugin --profile desktop add "file:<解压目录>/dsh-whale-splash-1.1.0.tgz"
- 安装成功但没动画：确认重启了 DSH；设置里「启用开屏动画」是打开的。

【卸载】
    dsh plugin --profile desktop remove dsh-whale-splash
（profile 也可能是 web，按你实际用的改。）

【换成自己的音乐】
默认音轨是插件内置的合成氛围音（无版权问题）。
想换：把任意音频转成 m4a，重命名为 splash.m4a，覆盖插件目录：
  ~/.dsh/profiles/<profile>/node_modules/dsh-whale-splash/assets/splash.m4a
然后重启 DSH。

【说明】
鲸鱼图形来自 DeepSeek 官方 logo（品牌标识，仅作个人开屏动画使用）。
插件代码 MIT。