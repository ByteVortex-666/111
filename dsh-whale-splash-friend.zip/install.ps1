﻿$ErrorActionPreference = 'Stop'
Write-Host "== dsh-whale-splash 开屏动画 安装器 ==" -ForegroundColor Cyan
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$tgz = Join-Path $here 'dsh-whale-splash-1.1.0.tgz'
if (-not (Test-Path $tgz)) { throw "找不到安装包：$tgz" }

$candidates = @(
  (Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd'),
  (Join-Path $env:LOCALAPPDATA 'Programs\DSH Desktop\resources\runtime\cli\bin\dsh.cmd')
)
$dsh = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $dsh) {
  $cmd = Get-Command dsh -ErrorAction SilentlyContinue
  if ($cmd) { $dsh = $cmd.Source }
}
if (-not $dsh) { throw "没找到 dsh 命令，请确认已安装 DeepSeek Harness（官方版）。" }

$profileName = 'desktop'
$profilesDir = Join-Path $env:USERPROFILE '.dsh\profiles'
if (-not (Test-Path (Join-Path $profilesDir 'desktop'))) { $profileName = 'web' }
if ($args.Count -ge 1 -and $args[0]) { $profileName = $args[0] }
Write-Host "使用 profile：$profileName"
& $dsh plugin --profile $profileName add "file:$($tgz -replace '\\','/')"
if ($LASTEXITCODE -ne 0) { throw "安装失败（退出码 $LASTEXITCODE）" }
Write-Host ""
Write-Host "安装完成！请完全退出 DSH（关掉窗口/托盘）再重新打开，开屏动画就会播放。" -ForegroundColor Green
Write-Host "设置 → 开屏动画：可开关、调音量、切换「完整开屏 / 仅 Logo」、关掉全屏。"